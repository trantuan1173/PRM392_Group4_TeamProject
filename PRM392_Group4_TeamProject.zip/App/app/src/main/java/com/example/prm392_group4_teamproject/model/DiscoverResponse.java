package com.example.prm392_group4_teamproject.model;

import java.util.List;

public class DiscoverResponse {
    private List<DiscoverUser> users;

    public List<DiscoverUser> getUsers() { return users; }
}

package com.example.prm392_group4_teamproject.model;

public class ApiResponse {
    private String message;
    private LocationData location;

    public String getMessage() {
        return message;
    }

    public LocationData getLocation() {
        return location;
    }
}

